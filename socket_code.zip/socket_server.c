/*
 *  Server program
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define SERVER_PORT	12345		/* should be over 1024 */
#define BUF_SIZE	1024		/* block transfer size */
#define QUEUE_SIZE	10		/* maximum no of pending reqs */

#define SERVER_MSG	"I am the server\n"

int fatal( char *str1, char *str2 )
{
    fprintf( stderr, str1, str2 );
    exit( -1 );
}

int main( int argc, char *argv[] )
{
    int			s,
			b,
			l,
			sa,
			on;
    char		buf[BUF_SIZE];	/* buffer for incoming line */
    struct sockaddr_in	channel;	/* holds IP address */

    memset( &channel, 0, sizeof( channel ) );	/* make all-zeros */
    channel.sin_family = AF_INET;
    channel.sin_addr.s_addr = htonl( INADDR_ANY );
    channel.sin_port = htons( SERVER_PORT );

    s = socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
    if( s < 0 )
	fatal( "%s: socket() failed\n", argv[0] );

    setsockopt( s, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof( on ) );

    b = bind( s, (struct sockaddr *)&channel, sizeof( channel ) );
    if( b < 0 )
	fatal( "%s: bind() failed\n", argv[0] );

    l = listen( s, QUEUE_SIZE );
    if( l < 0 )
	fatal( "%s: listen() failed\n", argv[0] );

    while( 1 ){
	sa = accept( s, 0, 0 );
	if( sa < 0 )
	    fatal( "%s: accept() failed\n", argv[0] );

	read( sa, buf, BUF_SIZE );

	printf( "%s received: %s\n", argv[0], buf );
	write( 1, SERVER_MSG, sizeof( SERVER_MSG ) );

	close( sa );
	if( strcmp( buf, "over" ) == 0 ){
	    close( s );
	    break;
	}
    }
}


