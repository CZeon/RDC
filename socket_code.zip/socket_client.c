/*
 *  Client program
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#define SERVER_PORT	12345		/* should be over 1024 */
#define BUF_SIZE	1024		/* block transfer size */

int fatal( char *str1, char *str2 )
{
    fprintf( stderr, str1, str2 );
    exit( -1 );
}


int main( int argc, char *argv[] )
{
    int			c,
			s;
    char		buf[BUF_SIZE];	/* buffer for incoming line */
    struct hostent	*h;		/* info about server */
    struct sockaddr_in	channel;	/* holds IP address */

    if( argc < 3 )
	fatal( "Usage: %s <server-name> <message>\n", argv[0] );

    h = gethostbyname( argv[1] );	/* get server's IP address */
    if( !h )
	fatal( "%s: gethostbyname() failed\n", argv[0] );

    s = socket( PF_INET, SOCK_STREAM, IPPROTO_TCP );
    if( s < 0 )
	fatal( "%s: socket() failed\n", argv[0] );

    memset( &channel, 0, sizeof( channel ) );
    channel.sin_family = AF_INET;
    memcpy( &channel.sin_addr.s_addr, h->h_addr, h->h_length );
    channel.sin_port = htons( SERVER_PORT );

    c = connect( s, (struct sockaddr *)&channel, sizeof( channel ) );
    if( c < 0 )
	fatal( "%s: connect() failed\n", argv[0] );

    write( s, argv[2], (strlen( argv[2] ) + 1) );

    while( 1 ){
	int	bytes = read( s, buf, BUF_SIZE );	/* read from socket */
	if( bytes <= 0 )
	    exit( 0 );
	write( 1, buf, bytes );
    }

    close( s );
}

